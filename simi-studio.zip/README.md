# simi-studio

This Project's purpose is to help developers create a new pwa-studio project based on Venia concept and add our [PWA Studio modules](https://www.simicart.com/blog/simicart-partner-mageplaza-pwa-studio-extensions/) via just a few simple steps.

## 1. Clone pwa-studio
```
git clone https://github.com/Simicart/simi-studio
cd simi-studio
yarn install
```

## 2. Run
To run
```
yarn run watch
```
